package com.example.demo;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

	public Consumer() {
		// TODO Auto-generated constructor stub
	}
	
	@JmsListener(destination = "ali.queue")
	public void recieveQueue(String text) {
		System.out.println("\n Consumer - listener program displaying below data");
		System.out.println(text);
	}

}
