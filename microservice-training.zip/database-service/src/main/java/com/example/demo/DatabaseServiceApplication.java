package com.example.demo;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseServiceApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(DatabaseServiceApplication.class, args);
	}
	
	private static final Logger log = LoggerFactory.getLogger(DatabaseServiceApplication.class);
	
	@Autowired
	private BookRepository repository;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		log.info("Start DB Application");
		
		repository.save(new Book("Microservices"));
		repository.save(new Book("Java"));
		repository.save(new Book("Python"));
		repository.save(new Book("Spark"));
		repository.save(new Book("JavaScript"));
		
		//Find
		System.out.println("\n Find all records ");
		repository.findAll().forEach(System.out::println);
		
		System.out.println("\n Find by Id record ");
		repository.findById(3L).ifPresent(System.out::println);
		
		System.out.println("\n Find by name records ");
		repository.findByName("Java").forEach(System.out::println);
		
		System.out.println("\n Find by name custom records ");
		repository.findByNameCustom("Python").forEach(System.out::println);
		
		
		//Delete
		/*
		System.out.println("\n Delete book by id");
		Book bookToDelete = repository.findById(3L).get();
		System.out.println("Deleting Book: "+bookToDelete.getName());
		repository.delete(bookToDelete);
		
		
		System.out.println("\n Delete book by title");
		repository.findByName("Microservices")
				.forEach(book -> {
					System.out.println("Deleting Book: "+book.getName());
					repository.delete(book);
				});
		
		System.out.println("\n Delete by id");
		repository.deleteById(155L);
		
		System.out.println("\n Delete all by id");
		repository.deleteAllById(Arrays.asList(153L, 154L, 156L));
		
		*/
		
		System.out.println("\n Delete by name");
		repository.deleteAll(repository.findByName("Spark"));
		
		
		
	}
	

}
