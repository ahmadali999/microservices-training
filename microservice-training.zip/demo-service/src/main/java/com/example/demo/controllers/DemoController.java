package com.example.demo.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class DemoController {

	public DemoController() {
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping("/servicename")
	public String getServiceName() {
		return "Welcome: Oracle India";
	}
	
	@RequestMapping("/serviceaddress")
	public String getServiceLocation() {
		return "Oracle Trivandrum";
	}
	
	@RequestMapping("/servicedetails")
	public String getServicedetails() {
		return "Micro Services";
	}

}
